/*
 Source Server         : 本地
 Source Server Type    : MySQL
 Source Server Version : 8.0.23
 Source Host           : localhost:3306
 Source Schema         : Metis

 Target Server Type    : MySQL
 Target Server Version :8.0.23

*/


/*create database Metis*/
drop database if exists `Metis`;
create database if not exists `Metis` default character set utf8mb4 default collate utf8mb4_0900_ai_ci;
use `Metis`;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

/*create table structure for Metis*/

-- ----------------------------
-- Table structure for creator
-- ----------------------------
DROP TABLE IF EXISTS `creator`;

create table `creator`(
`ID`  int primary key not null unique comment'作/译者编号',
`Name` varchar(50) not null comment'作/译者姓名',
`Nationality` varchar(20) default'未知' comment'作/译者国籍',
`Birthday` date default null comment'作/译者出生日期',
`Deathday` date default null comment'作/译者死亡日期',
`Introduction` text comment'作/译者简介',
`Foreign_name` varchar(50) default null comment'作/译者外文姓名',
key `creator_name` (`Name`)
);

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;

create table `category`(
`Subclass` varchar(20) primary key not null unique comment'子类',
`Class`  varchar(20) not null comment'大类');

-- ----------------------------
-- Table structure for press
-- ----------------------------
DROP TABLE IF EXISTS `press`;

create table `press`(
`PressID` mediumint not null unique primary key comment'出版社编号',
`PressName` varchar(20) not null comment'出版社名',
`Contact` varchar(50) not null comment'联系人',
`Tel` varchar(20) not null comment'联系电话',
`Address` varchar(50) comment'出版社地址');

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS `book`;

create table `book`(
`ISBN` varchar(20) primary key not null unique comment'书号',
`Name` varchar(50) not null comment'书名',
`Author` int not null comment'作者ID',
`Translater` varchar(50) default null comment'译者姓名',
`Press` mediumint not null comment'出版社编号',
`PressTime` date comment'出版时间',
`Picture` blob comment'封面图片',
`Subclass` varchar(20) not null comment'子类',
`Stock` int not null default 0 comment'库存余量',  
`TotalSales` int not null default 0 comment'累计已售',
`Score` float(2,1) default null comment'评分',
`Introduction` text comment'书籍简介',
`Cost` decimal(7,2) not null comment'进货价',
CONSTRAINT `FK_book_author_to_creator` FOREIGN KEY (`Author`) REFERENCES `creator` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE,
CONSTRAINT `FK_book_press_to_press` FOREIGN KEY (`Press`) REFERENCES `press` (`PressID`) ON DELETE RESTRICT ON UPDATE CASCADE,
CONSTRAINT `FK_book_class_to_category` FOREIGN KEY (`Subclass`) REFERENCES `category` (`Subclass`) ON DELETE RESTRICT ON UPDATE CASCADE
);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;

create table `user`(
`ID` int primary key auto_increment comment'用户编号',
`state` enum('初级','中级','高级') not null comment'会员状态',
`Name` varchar(50) not null comment'用户姓名',
`Address` varchar(50) comment'收货地址',
`Telephone` varchar(20) not null unique comment'联系电话',
`email` varchar(30) not null comment'用户邮箱',
`Credit` smallint not null default 0 comment'用户积分',
`Password` varchar(20) not null comment'密码'
) auto_increment=100000;

-- ---------------------------------
-- Table structure for shopping_cart
-- ---------------------------------
DROP TABLE IF EXISTS `shopping_cart`;

create table `shopping_cart`(
`ID` int not null comment'用户编号',
`ISBN` varchar(20) not null comment'书号',
`Number` tinyint not null comment'数量',
primary key(`ID`,`ISBN`),
CONSTRAINT `FK_shopping_cart_ID_to_user` FOREIGN KEY (`ID`) REFERENCES `user` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE,
CONSTRAINT `FK_shopping_cart_ISBN_to_book` FOREIGN KEY (`ISBN`) REFERENCES `book` (`ISBN`) ON DELETE RESTRICT ON UPDATE CASCADE
);

-- ----------------------------
-- Table structure for review
-- ----------------------------
DROP TABLE IF EXISTS `review`;

create table `review`(
`ID` int not null comment'用户编号',
`ISBN` varchar(20) not null comment'书号',
`Comment` varchar(50) default'该用户未评价。' comment'用户评价',
`Score` enum('1','2','3','4','5') comment'评分',
primary key(`ID`,`ISBN`),
CONSTRAINT `FK_review_ID_to_user` FOREIGN KEY (`ID`) REFERENCES `user` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE,
CONSTRAINT `FK_review_ISBN_to_book` FOREIGN KEY (`ISBN`) REFERENCES `book` (`ISBN`) ON DELETE RESTRICT ON UPDATE CASCADE
);

-- ----------------------------
-- Table structure for staff
-- ----------------------------
DROP TABLE IF EXISTS `staff`;

create table `Staff`(
`ID` tinyint primary key not null auto_increment comment'管理人员编号',
`Password` varchar(20) not null comment'管理员密码',
`Name` varchar(20) not null comment'管理员姓名'
)auto_increment=1;

-- ----------------------------
-- Table structure for sales
-- ----------------------------
DROP TABLE IF EXISTS `Sales`;

create table `Sales`(
`ISBN` varchar(20) not null comment'书号',
`Type` enum('初级','中级','高级') not null comment'客户类型',
`Price` decimal(7,2) not null comment'价格',
primary key(`ISBN`,`Type`),
CONSTRAINT `FK_Sales_ISBN_to_book` FOREIGN KEY (`ISBN`) REFERENCES `book` (`ISBN`) ON DELETE RESTRICT ON UPDATE CASCADE
);

-- ----------------------------
-- Table structure for order
-- ----------------------------
 DROP TABLE IF EXISTS `order`;
 
 create table `order`(
 `OrderID` int primary key not null comment'订单号',
 `Time` datetime not null default current_timestamp comment'下单时间',
 `ISBN` varchar(20) not null comment'书号',
 `Total` smallint not null default 1 comment'数量',
 `ID` int not null comment'下单用户',
 `Status` enum('已付款','已收货','退货申请中','已退货') not null comment'订单状态',
 CONSTRAINT `FK_order_ID_to_user` FOREIGN KEY (`ID`) REFERENCES `user` (`ID`) on delete restrict on update cascade,
 CONSTRAINT `FK_order_ISBN_to_book` FOREIGN KEY (`ISBN`) REFERENCES `book` (`ISBN`) on delete restrict on update cascade
);

-- ----------------------------
-- Table structure for return
-- ----------------------------
DROP TABLE IF EXISTS `return`;

create table `return`(
`OrderID` int not null unique comment'订单号',
`Return_reason` varchar(50),
`Result` enum('是','否','待审核') default '待审核' comment'审核通过',
`ISBN` varchar(20) not null comment'书号',
 primary key(`OrderID`,`ISBN`),
 CONSTRAINT `FK_return_OrderID_to_order` FOREIGN KEY (`OrderID`) REFERENCES `order` (`OrderID`) ON DELETE RESTRICT ON UPDATE CASCADE
);
 
-- -----------------------------------
-- Trigger structure for StockDecrease
-- -----------------------------------
DELIMITER $
create trigger StockDecrease after insert on `order` for each row
begin
declare a int;
declare amount int;
declare b int;
set a=(select `Total` from `order` where `OrderID`= new.orderid);
set amount=(select `Stock` from `book` where `ISBN`=new.ISBN);
set b=(select `TotalSales` from `book` where `ISBN`=new.ISBN);
update book set `Stock`=(amount-a),`TotalSales`=(b+a) where `ISBN`=new.ISBN;
end$
DELIMITER ;
/*
当产生新订单时，对图书表的相应图书的库存以及累计销售量进行更新
*/

-- -----------------------------------
-- Trigger structure for StockIncrease
-- -----------------------------------
DELIMITER $
create trigger StockIncrease after update on `return` for each row
begin
declare a int;
declare amount int;
declare b int;
set a=(select `Total` from `order` where `OrderID`= new.orderid);
set amount=(select `Stock` from `book` where `ISBN`=new.ISBN);
set b=(select `TotalSales` from `book` where `ISBN`=new.ISBN);
if (select `Result` from `return` where `OrderID`= new.orderid)='是' then
update book set `Stock`=(amount+a),`TotalSales`=(b-a) where `ISBN`=new.ISBN;
update `order` set `status`='已退货' where `OrderID`=new.orderid;
end if;
end$
DELIMITER ;
/*
当退货审核通过时，对图书的库存以及销售总量进行更新,同时将订单状态更新为“已退货”
*/

-- -----------------------------------
-- Trigger structure for ReturnRequest
-- -----------------------------------
DELIMITER $
create trigger ReturnRequest after insert on `return` for each row
begin
if (select `Result` from `return` where `OrderID`= new.orderid)='待审核' then
update `order` set `status`='退货申请中' where `OrderID`=new.OrderID;
end if;
end$
DELIMITER ;
/*
当产生新的退货申请时，将订单状态相应更新为“退货申请中”
*/

-- ---------------------------------
-- Trigger structure for ScoreUpdate
-- ---------------------------------
DELIMITER $
create trigger ScoreUpdate after insert on `review` for each row
begin
declare a float(2,1);
declare b char(1);
declare c int;
declare total int;
set a=(select `Score` from `book` where `ISBN`=new.ISBN);
set b=new.`Score`;
set c=(select `TotalSales` from `book` where `ISBN`=new.ISBN);
update `book` set `Score`=(a*(c-1)+convert(b,signed))/c where `ISBN`=new.ISBN;
end$
DELIMITER ;
/*
当产生新评价时，对相应图书的评分进行更新
*/

-- ---------------------------------
-- Trigger structure for Levelup
-- ---------------------------------
DELIMITER $
create trigger Levelup after update on `order` for each row
begin
declare a smallint;
declare b smallint;
if(select `Status` from `order` where orderid=new.orderid)='已收货' then
set a=(select `credit` from `user` where `id`=new.id);
set b=(select `total` from `order` where `orderid`=new.orderid);
update `user` set `credit`=(a+b) where `id`=new.id;
end if;
if(select `state` from `user` where `id`=new.id)='初级' and (a+b)>=50 then
update `user` set `state`='中级' where `id`=new.id;
end if;
if(select `state` from `user` where `id`=new.id)='中级' and (a+b)>=150 then
update `user` set `state`='高级' where `id`=new.id;
end if;
end$
DELIMITER ;
/*
当完成新订单时，更新用户积分；如果积分达到一定标准，更新会员等级
*/